def FuncionPaquete2 ():
    print("Funcion Paquete 2")

