from setuptools import setup

setup(    name="mipaquete",
    version="1.0",
    description="mi primer paquete redistribuible",
    author="Franco",
    packages=["paquete"],
    
)

